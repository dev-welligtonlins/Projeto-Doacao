SET SESSION FOREIGN_KEY_CHECKS=0;

INSERT INTO `teste` VALUES
    (1, 'Elias'),
    (3, 'Ezequiel'),
    (2, 'Hedelvan'),
    (4, 'João Vitor'),
    (5, 'Wellington');

INSERT INTO `donor` VALUES (1, TRUE, '2020-01-19 03:14:07.000000', 'Rio Branco', 'Brasil', '000.000.000-00', 'Bairro do Centro', 'fulano@email.com', 'Fulano de Tal', 'MASCULINO', 'Rua do Central', '1560', '69911000', 'Acre'),
(2, TRUE, '2019-01-19 13:20:05.000000', 'Rio Branco', 'Brasil', '000.000.000-01', 'Bairro do Ponte', 'beltrano@email.com', 'Beltrano de Tal', 'MASCULINO', 'Rua do Canal', '35', '69911001', 'Acre'),
(3, TRUE, '2018-01-19 03:40:08.000000', 'Rio Branco', 'Brasil', '000.000.000-02', 'Bairro do Planalto', 'sicrano@email.com', 'Sicrano de Tal', 'MASCULINO', 'Rua do Poliana', '358', '69911002', 'Acre');

INSERT INTO `institution` VALUES (1, TRUE, 'Rio Branco', '00.000.000/0001-00', 'Instituto Doar Mais LTDA', 'Brasil', 'Essa empresa atua no ramo de contribuições sociais.', 'Bairro do Centro', 'Instituição Doação é Mais', 'Rua do Central', '1560', '2020-01-19 03:14:07.000000', '69911000', 'Acre'),
(2, TRUE, 'Rio Branco', '00.000.000/0001-01', 'Instituto Doar Pelo Brasil LTDA', 'Brasil', 'Essa empresa atua no ramo de contribuições sociais no Brasil.', 'Bairro do Aeroporto', 'Instituição Doar pelo Brasil', 'Rua Faria', '2536', '2015-05-12 03:14:07.000000', '69911001', 'Acre');

INSERT INTO `campaign` VALUES (1, TRUE, '/donation-default.png', 'Essa é a descrição da campanha de teste.', NULL, 'PROGRESS', 'Título da Campanha de Teste', 1);
INSERT INTO `campaign` VALUES (2, TRUE, '/donation-default.png', 'itens', NULL, 'PROGRESS', 'campanha com itens', 1);

INSERT INTO `item` VALUES (1, 0, 'sla', 'arroz', 100, 'QUILOGRAMA', 2),
(2, 0, 'hgmjh', 'feijao', 2003, 'QUILOGRAMA', 2),
(3, 0, 'ssdsadvb', 'macarrao', 2321, 'METRO', 2);

INSERT INTO `favorite` VALUES (1, 1, 1),
(2, 1, 2),
(3, 2, 2);

INSERT INTO `enjoy` VALUES (1, FALSE, 1, 1),
(2, TRUE, 2, 1),
(3, TRUE, 1, 2),
(4, TRUE, 1, 3),
(5, TRUE, 2, 3);

INSERT INTO `feedback` VALUES (1, TRUE, 'Gostei muito dessa instituição, ótimo trabalho realizado.', 1, 1),
(2, TRUE, 'Não gostei muito dessa instituição, trabalho mediano realizado.', 1, 2),
(3, TRUE, 'Trabalhos muito bem executados.', 2, 1),
(4, TRUE, 'Ótima instituição, sem comentários.', 3, 2);

SET SESSION FOREIGN_KEY_CHECKS=1;
