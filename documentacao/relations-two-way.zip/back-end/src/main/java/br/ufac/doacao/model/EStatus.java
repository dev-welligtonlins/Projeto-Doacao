package br.ufac.doacao.model;

public enum EStatus {
    PROGRESS,
    PAUSED,
    FINISHED;
}
