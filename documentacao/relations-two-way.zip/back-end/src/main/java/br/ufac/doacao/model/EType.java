package br.ufac.doacao.model;

public enum EType {
    UNIDADE,
    QUILOGRAMA,
    LITRO,
    METRO,
    BRL;
}
