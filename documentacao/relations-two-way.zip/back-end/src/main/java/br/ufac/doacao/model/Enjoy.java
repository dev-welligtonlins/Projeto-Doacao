package br.ufac.doacao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Enjoy implements Serializable {

    @Id
    Long id;

    @JsonBackReference
    @ManyToOne
    private Donor donor;

    @JsonBackReference
    @ManyToOne
    private Campaign campaign;

    @Column(nullable = false)
    private boolean enjoyed;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Donor getDonor() {
        return donor;
    }

    public void setDonor(Donor donor) {
        this.donor = donor;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    public boolean isEnjoyed() {
        return enjoyed;
    }

    public void setEnjoyed(boolean enjoyed) {
        this.enjoyed = enjoyed;
    }

}
