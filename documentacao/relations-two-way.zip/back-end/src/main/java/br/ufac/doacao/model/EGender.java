package br.ufac.doacao.model;

public enum EGender {
    MASCULINO,
    FEMININO,
    OUTRO;
}
