SET SESSION FOREIGN_KEY_CHECKS=0;

-- As colunas da tabela são nomeadas em ordem alfabética, exceto a coluna id, que sempre vem primeiro.

INSERT INTO `teste` VALUES
    (1, 'Elias'),
    (3, 'Ezequiel'),
    (2, 'Hedelvan'),
    (4, 'João Vitor'),
    (5, 'Wellington');

INSERT INTO `user` VALUES
    (1, TRUE, '$2a$10$zArhMpAXoIhDRvqmJSPI2uDJbGxoQft9g2LCa.7fBCOXDuqKVC6cS', 'ROLE_ADMIN', 'admin');

SET SESSION FOREIGN_KEY_CHECKS=1;