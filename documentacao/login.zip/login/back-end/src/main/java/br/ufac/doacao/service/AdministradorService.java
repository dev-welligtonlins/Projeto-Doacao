package br.ufac.doacao.service;

import java.util.List;

import org.springframework.stereotype.Service;

import br.ufac.doacao.model.Administrador;
import br.ufac.doacao.repository.AdministradorRepository;

@Service
public class AdministradorService implements ICrudService<Administrador> {

    // TODO: renomear todas as variáveis repo para repository
    private final AdministradorRepository repo;

    public AdministradorService(AdministradorRepository repo) {
        this.repo = repo;
    }

    @Override
    public Administrador save(Administrador object) {
        return repo.save(object);
    }

    @Override
    public List<Administrador> getAll() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Administrador getById(Long id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<Administrador> getByAll(String termoBusca) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void delete(Long id) {
        // TODO Auto-generated method stub
        
    }

}
