package br.ufac.doacao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.ufac.doacao.model.User;

public interface UserRepository extends JpaRepository<User, Long> {

    @Query(
        "SELECT p FROM User p WHERE p.username LIKE %?1%"
    )
    List<User> findByAll(String termoBusca);

    User findByUsername(String username);
    
}