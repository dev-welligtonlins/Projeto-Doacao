package br.ufac.doacao.model;

public enum ERole {

    ROLE_ADMIN,
    ROLE_INSTITUTION,
    ROLE_DONOR

}
