package br.ufac.doacao.service;

import java.util.List;

import org.springframework.stereotype.Service;

import br.ufac.doacao.model.Campaign;
import br.ufac.doacao.repository.CampaignRepository;

@Service
public class CampaignService implements ICrudService<Campaign> {

    private final CampaignRepository repo;

    public CampaignService(CampaignRepository repo) {
        this.repo = repo;
    }

    @Override
    public Campaign save(Campaign object) {
        return repo.save(object);
    }

    @Override
    public List<Campaign> getAll() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Campaign getById(Long id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<Campaign> getByAll(String termoBusca) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void delete(Long id) {
        // TODO Auto-generated method stub
        
    }

}
