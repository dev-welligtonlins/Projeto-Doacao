package br.ufac.doacao.service;

import java.util.List;

import org.springframework.stereotype.Service;

import br.ufac.doacao.model.Institution;
import br.ufac.doacao.repository.InstitutionRepository;

@Service
public class InstitutionService implements ICrudService<Institution> {

    private final InstitutionRepository repo;

    public InstitutionService(InstitutionRepository repo) {
        this.repo = repo;
    }

    @Override
    public Institution save(Institution object) {

        return repo.save(object);
    }

    @Override
    public List<Institution> getAll() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Institution getById(Long id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<Institution> getByAll(String termoBusca) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void delete(Long id) {
        // TODO Auto-generated method stub
        
    }

}
