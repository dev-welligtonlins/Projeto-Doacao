package br.ufac.doacao.service;

import java.util.List;
import org.springframework.stereotype.Service;

import br.ufac.doacao.model.User;
import br.ufac.doacao.repository.UserRepository;

@Service
public class UserService implements ICrudService<User> {

    private final UserRepository repo;

    public UserService(UserRepository repo) {
        this.repo = repo;
    }

    @Override
    public List<User> getAll() {
        List<User> results = repo.findAll();
        return results;
    }

    @Override
    public User getById(Long id) {
        User result = repo.findById(id).orElse(null);
        return result;
    }

    @Override
    public List<User> getByAll(String termoBusca) {
        List<User> results = repo.findByAll(termoBusca);
        return results;
    }

    @Override
    public User save(User objeto) {
        if (objeto.getPassword() == null) {
            Long id = objeto.getId();
            User user = repo.findById(id).orElse(null);
            if (user != null) {
                objeto.setPassword(user.getPassword(), false);
            }
        }
        return repo.save(objeto);
    }

    @Override
    public void delete(Long id) {
        repo.deleteById(id);
    }

    public User getByUsername(String username) {
        User user = repo.findByUsername(username);
        return user;
    }

}
