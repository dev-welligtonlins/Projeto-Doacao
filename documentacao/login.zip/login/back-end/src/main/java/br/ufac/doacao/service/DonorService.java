package br.ufac.doacao.service;

import java.util.List;

import org.springframework.stereotype.Service;

import br.ufac.doacao.model.Donor;
import br.ufac.doacao.repository.DonorRepository;

@Service
public class DonorService implements ICrudService<Donor> {

    private final DonorRepository repo;

    public DonorService(DonorRepository repo) {
        this.repo = repo;
    }

    @Override
    public Donor save(Donor object) {
        return repo.save(object);
    }

    @Override
    public List<Donor> getAll() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Donor getById(Long id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<Donor> getByAll(String termoBusca) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void delete(Long id) {
        // TODO Auto-generated method stub
        
    }

}
