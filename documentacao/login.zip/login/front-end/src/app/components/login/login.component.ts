import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { User } from 'src/app/model/user';
import { LoginService } from 'src/app/service/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {

  constructor(
    private service: LoginService
  ) { }

  user: User = <User>{};

  submit(form: NgForm): void {
    this.service.login(this.user);
    form.resetForm();
  }

  ngOnInit(): void {
  }

}
